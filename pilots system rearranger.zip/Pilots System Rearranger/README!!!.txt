Pilots System Rearranger:

-Dres is a moon of Eve
-Ike is a moon of Kerbin
-Laythe is a planet, with 1 moon, Moho
-Duna has 2 moons, Gilly and Bop
-Pol is a lonely moon where Dres normally is
-Jool now has Minmus and Eeloo

thanks for playing my mod! :D